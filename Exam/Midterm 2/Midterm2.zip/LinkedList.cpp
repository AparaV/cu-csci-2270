#include <iostream>

using namespace std;

struct Node{
	int key;
	Node *next;
	Node *previous;
	Node(int k, Node *n, Node *p){
		key = k;
		next = n;
		previous = p;
	}
};

class LinkedList{
	private:
		Node *head;
		Node *search(int value){
		 
		}

	public:

		LinkedList(){head = NULL;};
		
		void getName()
		   {
			cout<<"Enter your Name Here...";
		   }

		void addNode(int value, int newVal){
			
			
			
			
			
			
			//Students need to write this method
			
			
			
			
			
			
		}
	
		
		
		
   Node *getHead()
      {
		return head;
      }


		void printList(){
			Node *x = head;
			while(x != NULL){
				cout<<x->key<<endl;
				x = x->next;
			}
		}
};