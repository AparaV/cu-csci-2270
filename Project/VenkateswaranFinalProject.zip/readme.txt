CSCI 2270 Project: Hash Table Performance Evalutation
Instructor: Rhonda Hoenigman
TA: Yang Li
Author: Aparajithan Venkateswaran

Running:
 $ g++ -std=c++11 main.cpp hashtable.cpp
 $ ./a.out <optional_size_argument>

optional_size_argument: Defines the size of the hash table. Defaults to 5147 if none is provided
